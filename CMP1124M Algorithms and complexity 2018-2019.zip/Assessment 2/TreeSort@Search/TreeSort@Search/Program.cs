﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
namespace TreeSort_Search
{
    class Program
    {
        static void Main(string[] args)
        {
            Node root = null;
            Tree BinarySearchTree = new Tree();
            double[] WeatherArray = {12.23, 45.34, 23.23, 77.565, 90.231};

            Stopwatch watch = Stopwatch.StartNew();

            for (int i=0;i<WeatherArray.Length;i++)
            {
                root = BinarySearchTree.Insert(root, WeatherArray[i]);// this puts the values of the array into the binary search tree.
            }
            BinarySearchTree.Traverse(root);// this allows the tree to seach through itself.
            //Console.ReadKey();
            Console.WriteLine("What are you looking for?");
            double search = Convert.ToDouble(Console.ReadLine());
            BinarySearchTreeSearch( root, search);
            Console.WriteLine(search);
            Console.ReadKey();
        }


        public static double BinarySearchTreeSearch(Node branch, double key)
        {
            if (branch == null) {
                return 0;
            }
            if (branch.value == key)
            {
                return key;
            }
            else if (key < branch.value)
            {
                return BinarySearchTreeSearch(branch.left, key);
            }
            else
            {
                return BinarySearchTreeSearch(branch.right, key);
            }
        }

    }
    class Node {
        public double value;
        public Node left;
        public Node right;
    }
    class Tree {
        public Node Insert(Node root, double New_value)
        {// inserts a new value into the tree
            if (root == null)
            {// if the current value in the tree is the last value...
                root = new Node
                {
                    value = New_value// putting that new double value into the new node we just created if the node was empty
                }; //the root becauses a new node, a new starting pooint to add values onto. the new node acts like a class so you call a data member from it.
              //  Console.WriteLine(root.value);// before sorting
            }
            else if (New_value < root.value)
            {// if the new value we are adding is less than the last value in the node then we add it to the left of the root
                root.left = Insert(root.left, New_value); // we insert the new value into the tree by calling the insert function which takes a node or location to insert into and the value
            }
            else {// if the value is greater than the last value in the node then we put it to the right of that value
                root.right = Insert(root.right, New_value);
            }
            return root;// then we return the root or value we are at
        }

        public void Traverse(Node root) {// to move around a tree we take in the top value and if it is not an empty tree then we go left before right this is an inorder traversal
            if (root == null) {// if it is empty then do nothing
                return;
            }
            Traverse(root.left);// if it is not empty then call the traverse function and keep going right until you have gone through all the values on the right side
            Console.WriteLine(root.value);
            Traverse(root.right);// Then call the traverse function for the left side until you have gone through all the values
            //Console.WriteLine(root.value);
        }
    }
}
