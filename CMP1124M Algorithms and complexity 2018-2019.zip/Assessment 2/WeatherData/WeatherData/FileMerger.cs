﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace WeatherData
{
    class FileMerger
    {
       public static void FilesToMerge(string A, string B, string filename) {
            StreamWriter File = new StreamWriter(filename);
            File.Write(A);
            File.Write(B);
            File.Close();
        }
    }
}
