﻿using System;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System.Text;
using System.Threading.Tasks;

namespace simulated_device
{
    class SimulatedDevice
    {
        private static DeviceClient s_deviceClient;

        // The device connection string to authenticate the device with your IoT hub.
		
        private readonly static string s_connectionString = "HostName=SRBTempSensorHub.azure-devices.net;DeviceId=SRB_MXCHIP;SharedAccessKey=SC8G/4luJd30orrwdfRyobdY6WV5awK9QxZkPZzY9TY=";

        // Async method to send simulated telemetry
        private static async void SendDeviceToCloudMessagesAsync()
        {
           
            
            Random rand = new Random();
			// Initial telemetry values
            double minTemperature = 20;
            double minHumidity = 60;
			double minAmbientLight = 20;
			double minDecibel = 5;

            while (true)
            {
                double currentTemperature = minTemperature + rand.NextDouble() * 15;
                double currentHumidity = minHumidity + rand.NextDouble() * 20;
				double currentAmbientLight = minAmbientLight + rand.NextDouble() * 20;
				double currentDecibel = minDecibel + rand.NextDouble() * 10;

                // Create JSON message
                var telemetryDataPoint = new
                {
                    temperature = currentTemperature,
                    humidity = currentHumidity,
					light = currentAmbientLight,
					decibel = currentDecibel
                };
                var messageString = JsonConvert.SerializeObject(telemetryDataPoint);
                var message = new Message(Encoding.ASCII.GetBytes(messageString));

                // Add a custom application property to the message.
                // An IoT hub can filter on these properties without access to the message body.
                message.Properties.Add("temperatureAlert", (currentTemperature > 30) ? "true" : "false");

                // Send the telemetry message
                await s_deviceClient.SendEventAsync(message);
                Console.WriteLine("{0} > Sending message1: {1}", DateTime.Now, messageString);

                await Task.Delay(4000);
            }
        }
        private static void Main(string[] args)
        {
            Console.WriteLine("IoT Hub  - Simulated Sensor Data. Ctrl-C to exit.\n");

            // Connect to the IoT hub using the MQTT protocol
            s_deviceClient = DeviceClient.CreateFromConnectionString(s_connectionString, TransportType.Mqtt);
            SendDeviceToCloudMessagesAsync();
            Console.ReadLine();
        }
    }
}
