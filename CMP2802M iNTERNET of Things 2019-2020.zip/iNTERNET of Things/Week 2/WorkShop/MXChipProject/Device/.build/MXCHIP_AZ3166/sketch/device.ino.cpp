#include <Arduino.h>
#line 1 "c:\\Users\\computing\\Documents\\IoTWorkbenchProjects\\projects\\MXChipProject\\Device\\device.ino"
#include <RGB_LED.h>
#include <OledDisplay.h>
RGB_LED led;
const int num_Colors = 5;
int delayMs = 2000; //(2000ms = 2s)
uint8_t colors[][num_Colors] = {//unsigned int
    {255, 0, 0}, // Red, 0 , 0
    {0, 255, 0}, // 0, Green, 0
    {0, 0, 255}, // 0, 0, Blue
    {128, 0, 128}, // Purple
    {255, 165, 0}, // Orange
};

#line 14 "c:\\Users\\computing\\Documents\\IoTWorkbenchProjects\\projects\\MXChipProject\\Device\\device.ino"
void setup();
#line 19 "c:\\Users\\computing\\Documents\\IoTWorkbenchProjects\\projects\\MXChipProject\\Device\\device.ino"
void loop();
#line 14 "c:\\Users\\computing\\Documents\\IoTWorkbenchProjects\\projects\\MXChipProject\\Device\\device.ino"
void setup(){

Screen.init();//initialise the display
}

void loop(){

int lcv = sizeof(colors) / num_Colors;// length of colour vector

for (int i = 0; i< lcv; i++){
led.setColor(colors[i][0], colors[i][1], colors[i][2]);
delay(delayMs);
Serial.printf("Color values: %d, %d, %d\n", colors[i][0], colors[i][1], colors[i][2]);
}
  // print a string to the screen with wrapped = false
    Screen.print("CMP2082M Module", false);
    delay(1000);
    // print a string to the screen with wrapped = true
    for(int i = 0; i<=3; i++)
    {
        char buf[100];
        sprintf(buf, "Hacked you!");
        Screen.print(i, buf);
    }
    delay(3000);
    // Clean up the screen
    Screen.clean();
    delay(1000);  
}
