# 1 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino"
# 2 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino" 2
# 3 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino" 2

# 5 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino" 2
# 6 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino" 2
# 7 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino" 2
// SENSOR VARIABLES
DevI2C *i2c;
HTS221Sensor *sensor;
float humidity = 0;
float temperature = 0;
float threshold = 25;
 // LED VARIABLES
int RED_LED = 20;
int GREEN_LED = 19;
int BLUE_LED = 39;

int message_delay = 5000;//miliseconds
void setup() {
  // initialise wifi
  WiFi.begin();
  // create conneciton to your IoT Hub that uses your device conneciton string
  DevKitMQTTClient_Init(true);
  // initialise the sensor
  i2c = new DevI2C(D14, D15);
  sensor = new HTS221Sensor(*i2c);
  sensor -> init(
# 27 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino" 3 4
                __null
# 27 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino"
                    );
  // initialise display
  Screen.init();
  //Dispay stuff on screen
  Screen.print(2, "Press A for temp");// display text on second line of display
  Screen.print(3, "Press B for hum");

  pinMode(USER_BUTTON_A, 0x1); // initialize button A pin as an input
  pinMode(USER_BUTTON_B, 0x1);

  pinMode(RED_LED, 0x2); // initialize the pins as digital output.
  pinMode(GREEN_LED, 0x2);
  pinMode(BLUE_LED, 0x2);
}
//used MQTT to send data to IOT devices
void sendData(const char *data) {
  time_t t = time(
# 43 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino" 3 4
                 __null
# 43 "c:\\Users\\Ghost\\OneDrive - University of Lincoln\\Year 2 second half\\iNTERNET of Things\\Week 3\\WorkShop\\SensorDevelpoment\\Device\\device.ino"
                     );
  char buf[sizeof "2011-10-08T07:07:09Z"];
  strftime(buf, sizeof buf, "%FT%TZ", gmtime(&t));

  EVENT_INSTANCE* message = DevKitMQTTClient_Event_Generate(data, MESSAGE);

  DevKitMQTTClient_Event_AddProp(message, "$$CreationTimeUtc", buf);
  DevKitMQTTClient_Event_AddProp(message, "$$MessageSchema", "temperature;v1");
  DevKitMQTTClient_Event_AddProp(message, "$$ContentType", "JSON");

  DevKitMQTTClient_SendEventInstance(message);
}

void loop() {


  // Get temperature
  temperature = getTempData(); //calls temp method and sets temp value
  Threshold(); //calls threshold method
  if(temperature>threshold){
  char TempsensorData[200]; // send temp data to iot Hub
  sprintf_s(TempsensorData, sizeof(TempsensorData),"{\"temperature threshold breached\":%s}",f2s(temperature, 1));
  sendData(TempsensorData);//calls sendata method and passes on temerature data
  }
  delay(500);

  //Get Humidity
  humidity = getHumidData();
  char HumidsensorData[200];
  sprintf_s(HumidsensorData, sizeof(HumidsensorData),"{\"humidity\":%s}",f2s(humidity, 1));
  sendData(HumidsensorData);

  delay(message_delay);
}

float getTempData(){
    Screen.clean();
    // enable sensor and get value
    sensor -> enable();
    sensor -> getTemperature(&temperature);
    //Say hello on screen
    Screen.print(1, "Hi from button A!");

    Screen.clean();
    // display temperature on screen
    char buff[16];
    sprintf(buff, "Temp:%sC\r\n", f2s(temperature, 1));
    Screen.print(1, buff);
    delay(1500);
    Screen.clean();
    return temperature;
}

float getHumidData(){
    Screen.clean();
    // enable sensor and get value
    sensor -> enable();
    sensor -> getHumidity(&humidity);
    //Say hello on screen
    Screen.print(1, "Hi from button B!");
    for (int i = 255; i >= 0; i--){analogWrite(BLUE_LED, i);delay(15);}
    delay(1000);
    Screen.clean();
    // display humidity on screen
    char buff[16];
    sprintf(buff, "Humidity:%sC\r\n", f2s(humidity, 1));
    Screen.print(1, buff);
    delay(1500);
    Screen.clean();
    return humidity;
}
float Threshold(){
  if(temperature>=threshold){ // fade red LED with decrement loop using analogueWrite
    for (int i = 255; i >= 0; i--){analogWrite(RED_LED, i);delay(15);}
  delay(1000);
  }
  else{
    for (int i = 255; i >= 0; i--){analogWrite(GREEN_LED, i);delay(15);}
  delay(1000);
  }
}
