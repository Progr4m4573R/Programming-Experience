Extension Authorisation Code: 9FRSM9L5WLDML7ZB
Autonomous Mobile Robotics Read Me

My assignment demonstrates a robot that is almost fully capable of solving all mazes, often getting stuck on corners, the robot is able to see and react to all different coloured squares and this is shown in the output console as it is clear the robot is away of the coloured squares as soon as they are seen. 

 To run the system simply download the code and launch it as normal. 