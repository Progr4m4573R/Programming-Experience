import rospy
from geometry_msgs.msg import Twist
from odometry_reading import odometry

class Receiver:
	def __init__(self):
		   rospy.init_node('receiver')
		self.subscriber = rospy.subscriber('/odom', odometry, callback=self.cb)
        self.p = rospy.Publisher('/mobile_base/commands/velocity', Twist, queue_size=1)

    def cb(self, odometry):
    	for x in range(10):
			if(odometry < 1_metre_forwards_equivalent):
				t = Twist()
				t.linear.x+=x
				self.p.publish(t)
			else:
				t.linear.x-=x
				self.p.publish(t)	

rec = Receiver()

rospy.spin()