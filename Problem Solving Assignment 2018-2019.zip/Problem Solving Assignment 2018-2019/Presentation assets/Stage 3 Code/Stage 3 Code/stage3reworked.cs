﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stage_3_Code
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {                
                Console.WriteLine("What month is your birthday");
                string ans = Console.ReadLine();
                int[] secret_code = new int[] { 6, 3, 3, 7, 5, 2, 7, 4, 1, 6, 3, 1 };
                string[] days = new string[] {"Sunday","Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
                string[] months = new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
                string month="";
                int code = 0;
                int date = 0;
                double absoluteval;
                for (int i=0;i<12;i++) {
                     while (ans != months[i]) {
                        i++;
                     }
                    month = months[i];
                    code = secret_code[i];
                    Console.WriteLine($"Please enter a day in {months[i]}");
                    date = Convert.ToInt32(Console.ReadLine());
                    double difference = date - code;
                    absoluteval = difference > 0 ? difference : difference+=7;
                    double daysaway = difference % 7;        
                    int my_day = Convert.ToInt32(daysaway);
                    Console.WriteLine(days[my_day]);
                    Console.ReadKey();
                }
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine($"Exception {e} thrown\nPlease make sure your code is exactly 12 digits long");
            }           
        }
    }
}
                       

