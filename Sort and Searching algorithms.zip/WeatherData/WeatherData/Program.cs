﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
namespace WeatherData
{
    class Program
    {
        static void Main(string[] args)
        {//Main Class
            Console.WriteLine("Choose a task\n1.Individual Arrays\n2.Merged Arrays");
            int task = Convert.ToInt32(Console.ReadLine());
            if (task == 1)
            {
                Console.WriteLine("1.High\n2.Mean\n3.Low");
                int section = Convert.ToInt32(Console.ReadLine());
                if (section == 1) {
                    Console.WriteLine("1.High_256\n2.High_2048\n3.High_4096");

                    int response = Convert.ToInt32(Console.ReadLine());
                    // section for High text file
                    if (response == 1) {
                        string HighWeatherDATA = File.ReadAllText("High_256.txt");
                        int N_0_Elements = 256;
                        double[] DoubleHighWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            BinarySearchTreeSort(DoubleHighWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            DescendingOrder_BubbleSort(DoubleHighWeatherArray, N_0_Elements);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleHighWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            QuickSort(DoubleHighWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int Searchcounter = 0;
                                LinearSearch(DoubleHighWeatherArray, key);


                                for (int i = 0; i < DoubleHighWeatherArray.Length;)
                                {
                                    while (key != DoubleHighWeatherArray[i])
                                    {
                                        i++;
                                        Searchcounter++;
                                    }
                                    foreach (int instance in DoubleHighWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleHighWeatherArray[i])
                                    {
                                        Console.WriteLine($"This search took {Searchcounter} steps to complete");
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"This search took {Searchcounter} steps to complete");
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleHighWeatherArray[i]} and {DoubleHighWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleHighWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleHighWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleHighWeatherArray.Length;)
                                    {
                                        while (key > DoubleHighWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleHighWeatherArray[i])
                                        {
                                            double left_side = key - DoubleHighWeatherArray[i - 1];
                                            double right_side = DoubleHighWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleHighWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value at index {i}");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    else if (response == 2) {

                        string HighWeatherDATA = File.ReadAllText("High_2048.txt");
                        int N_0_Elements = 2048;
                        double[] DoubleHighWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleHighWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            DescendingOrder_BubbleSort(DoubleHighWeatherArray, N_0_Elements);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleHighWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            QuickSort(DoubleHighWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleHighWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                BinarySearch_R(key, DoubleHighWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleHighWeatherArray.Length;)
                                {
                                    while (key != DoubleHighWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleHighWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleHighWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleHighWeatherArray[i]} and {DoubleHighWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleHighWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleHighWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleHighWeatherArray.Length;)
                                    {
                                        while (key > DoubleHighWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleHighWeatherArray[i])
                                        {
                                            double left_side = key - DoubleHighWeatherArray[i - 1];
                                            double right_side = DoubleHighWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleHighWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    else if (response == 3) {

                        string HighWeatherDATA = File.ReadAllText("High_4096.txt");
                        int N_0_Elements = 4096;
                        double[] DoubleHighWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleHighWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            DescendingOrder_BubbleSort(DoubleHighWeatherArray, N_0_Elements);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleHighWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(HighWeatherDATA, DoubleHighWeatherArray, N_0_Elements);
                            QuickSort(DoubleHighWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleHighWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                BinarySearch_R(key, DoubleHighWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleHighWeatherArray.Length;)
                                {
                                    while (key != DoubleHighWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleHighWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleHighWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleHighWeatherArray[i]} and {DoubleHighWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleHighWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleHighWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleHighWeatherArray.Length;)
                                    {
                                        while (key > DoubleHighWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleHighWeatherArray[i])
                                        {
                                            double left_side = key - DoubleHighWeatherArray[i - 1];
                                            double right_side = DoubleHighWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleHighWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    // end section for High text file
                }
                    // section for Mean text file
                else if (section == 2) {
                    Console.WriteLine("1.Mean_256\n2.Mean_2048\n3.Mean_4096");

                    int response = Convert.ToInt32(Console.ReadLine());
              
                    if (response == 1)
                    {
                        string MeanWeatherDATA = File.ReadAllText("Mean_256.txt");
                        int N_0_Elements = 256;
                        double[] DoubleMeanWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleMeanWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            DescendingOrder_InsertionSort(DoubleMeanWeatherArray);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleMeanWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            QuickSort(DoubleMeanWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleMeanWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                Node r = new Node();// create an instance of node so i can call it
                                BinarySearch_R(key, DoubleMeanWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleMeanWeatherArray.Length;)
                                {
                                    while (key != DoubleMeanWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleMeanWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleMeanWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleMeanWeatherArray[i]} and {DoubleMeanWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleMeanWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleMeanWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleMeanWeatherArray.Length;)
                                    {
                                        while (key > DoubleMeanWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleMeanWeatherArray[i])
                                        {
                                            double left_side = key - DoubleMeanWeatherArray[i - 1];
                                            double right_side = DoubleMeanWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleMeanWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleMeanWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    else if (response == 2)
                    {
                        string MeanWeatherDATA = File.ReadAllText("Mean_2048.txt");
                        int N_0_Elements = 2048;
                        double[] DoubleMeanWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleMeanWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            DescendingOrder_InsertionSort(DoubleMeanWeatherArray);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleMeanWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            QuickSort(DoubleMeanWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleMeanWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                BinarySearch_R(key, DoubleMeanWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleMeanWeatherArray.Length;)
                                {
                                    while (key != DoubleMeanWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleMeanWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleMeanWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleMeanWeatherArray[i]} and {DoubleMeanWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleMeanWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleMeanWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleMeanWeatherArray.Length;)
                                    {
                                        while (key > DoubleMeanWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleMeanWeatherArray[i])
                                        {
                                            double left_side = key - DoubleMeanWeatherArray[i - 1];
                                            double right_side = DoubleMeanWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleMeanWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleMeanWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    else if (response == 3)
                    {
                        string MeanWeatherDATA = File.ReadAllText("Mean_4096.txt");
                        int N_0_Elements = 4096;
                        double[] DoubleMeanWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleMeanWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            DescendingOrder_InsertionSort(DoubleMeanWeatherArray);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleMeanWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(MeanWeatherDATA, DoubleMeanWeatherArray, N_0_Elements);
                            QuickSort(DoubleMeanWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleMeanWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                BinarySearch_R(key, DoubleMeanWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleMeanWeatherArray.Length;)
                                {
                                    while (key != DoubleMeanWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleMeanWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleMeanWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleMeanWeatherArray[i]} and {DoubleMeanWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleMeanWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleMeanWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleMeanWeatherArray.Length;)
                                    {
                                        while (key > DoubleMeanWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleMeanWeatherArray[i])
                                        {
                                            double left_side = key - DoubleMeanWeatherArray[i - 1];
                                            double right_side = DoubleMeanWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleMeanWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleMeanWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }


                }
                // end section for Mean text file


                else if (section == 3) {
                    Console.WriteLine("1.Low_256\n2.Low_2048\n3.Low_4096");

                    int response = Convert.ToInt32(Console.ReadLine());
                    // section for Mean text file
                    if (response == 1)
                    {
                        string LowWeatherDATA = File.ReadAllText("Low_256.txt");
                        int N_0_Elements = 256;
                        double[] DoubleLowWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            DescendingOrderQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            QuickSort(DoubleLowWeatherArray,Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleLowWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                BinarySearch_R(key, DoubleLowWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleLowWeatherArray.Length;)
                                {
                                    while (key != DoubleLowWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleLowWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleLowWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleLowWeatherArray[i]} and {DoubleLowWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleLowWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleLowWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleLowWeatherArray.Length;)
                                    {
                                        while (key > DoubleLowWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleLowWeatherArray[i])
                                        {
                                            double left_side = key - DoubleLowWeatherArray[i - 1];
                                            double right_side = DoubleLowWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleLowWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleLowWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    else if (response == 2)
                    {
                        string LowWeatherDATA = File.ReadAllText("Low_2048.txt");
                        int N_0_Elements = 2048;
                        double[] DoubleLowWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            DescendingOrderQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            QuickSort(DoubleLowWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleLowWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                BinarySearch_R(key, DoubleLowWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleLowWeatherArray.Length;)
                                {
                                    while (key != DoubleLowWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleLowWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleLowWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleLowWeatherArray[i]} and {DoubleLowWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleLowWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleLowWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleLowWeatherArray.Length;)
                                    {
                                        while (key > DoubleLowWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleLowWeatherArray[i])
                                        {
                                            double left_side = key - DoubleLowWeatherArray[i - 1];
                                            double right_side = DoubleLowWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleLowWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleLowWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    else if (response == 3)
                    {
                        string LowWeatherDATA = File.ReadAllText("Low_4096.txt");
                        int N_0_Elements = 4096;
                        double[] DoubleLowWeatherArray = new double[N_0_Elements];// makes a double array that is the size of the string list.// capacity is like length for arrays

                        Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                        int order = Convert.ToInt32(Console.ReadLine());
                        if (order == 1)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            AscendingOrderQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 2)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            DescendingOrderQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 3)
                        {
                            int counter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            Displacement_ValueQuickSort(DoubleLowWeatherArray, counter);
                        }
                        else if (order == 4)
                        {
                            int Sortcounter = 0;
                            PrintData(LowWeatherDATA, DoubleLowWeatherArray, N_0_Elements);
                            QuickSort(DoubleLowWeatherArray, Sortcounter);
                            try
                            {
                                int mentions = 0;
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleLowWeatherArray.Length - 1;
                                int Searchcounter = 0;
                                BinarySearch_R(key, DoubleLowWeatherArray, low, high, ref Searchcounter);
                                Console.WriteLine($"This search took {Searchcounter} steps to complete");

                                for (int i = 0; i < DoubleLowWeatherArray.Length;)
                                {
                                    while (key != DoubleLowWeatherArray[i])
                                    {
                                        i++;
                                    }
                                    foreach (int instance in DoubleLowWeatherArray)
                                    {
                                        if (key == instance)
                                        {
                                            mentions++;
                                        }
                                    }
                                    if (key == DoubleLowWeatherArray[i])
                                    {
                                        Console.WriteLine($"{key} is the {i}th value in your array");
                                        break;
                                    }
                                    if (mentions > 1)
                                    {
                                        Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleLowWeatherArray[i]} and {DoubleLowWeatherArray[i + 1]}");
                                        break;
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException)
                            {
                                Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                                string answer = Console.ReadLine();

                                if (answer.ToUpper() == "Y")
                                {

                                    Console.WriteLine("What Value are you looking for?");
                                    double key = double.Parse(Console.ReadLine());
                                    int low = 0;
                                    int high = DoubleLowWeatherArray.Length - 1;
                                    int counter = 0;
                                    BinarySearch_R(key, DoubleLowWeatherArray, low, high, ref counter);

                                    for (int i = 0; i < DoubleLowWeatherArray.Length;)
                                    {
                                        while (key > DoubleLowWeatherArray[i])
                                        {
                                            i++;
                                        }
                                        /*  if (key < DoubleHighWeatherArray[i])
                                          {
                                              Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                              break;
                                          }*/
                                        if (key < DoubleLowWeatherArray[i])
                                        {
                                            double left_side = key - DoubleLowWeatherArray[i - 1];
                                            double right_side = DoubleLowWeatherArray[i] - key;
                                            //double closestvalue = right_side > left_side ? left_side : right_side;
                                            if (right_side > left_side)
                                                Console.WriteLine($"{DoubleLowWeatherArray[i - 1]} would be the closest value");
                                            else
                                            {
                                                Console.WriteLine($"{DoubleLowWeatherArray[i]} would be the closest value");
                                            }
                                            break;
                                        }
                                    }
                                }
                                else if (answer.ToUpper() == "N")
                                {
                                }
                            }
                            catch (Exception e) { Console.WriteLine(e.Message); }
                        }
                    }
                    // end section for Low 256 text file
                }
                // section for Low 256 text file

            }

            else if (task == 2)
            {
                Console.WriteLine("1.Merged Low_High_256 File\n2.Merged Low_High_2048 File\n3.Merged Low_High_4096 File");
                int option = Convert.ToInt32(Console.ReadLine());

                if (option == 1)
                {
                    Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                    int order = Convert.ToInt32(Console.ReadLine());
                    if (order == 1)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_256.txt");
                        string High = File.ReadAllText("High_256.txt");
                        int N_O_Elements = 512;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_256.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        AscendingOrderQuickSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 2)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_256.txt");
                        string High = File.ReadAllText("High_256.txt");
                        int N_O_Elements = 512;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_256.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        DescendingOrderQuickSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 3)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_256.txt");
                        string High = File.ReadAllText("High_256.txt");
                        int N_O_Elements = 512;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_256.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        Displacement_ValueQuickSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 4)
                    {
                        int Sortcounter = 0;
                        string Low = File.ReadAllText("Low_256.txt");
                        string High = File.ReadAllText("High_256.txt");
                        int N_O_Elements = 512;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_256.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        QuickSort(DoubleHigh_Low_Array, Sortcounter);
                        try
                        {
                            int mentions = 0;
                            Console.WriteLine("What Value are you looking for?");
                            double key = double.Parse(Console.ReadLine());
                            int low = 0;
                            int high = DoubleHigh_Low_Array.Length - 1;
                            int Searchcounter = 0;
                            BinarySearch_R(key, DoubleHigh_Low_Array, low, high, ref Searchcounter);
                            Console.WriteLine($"This search took {Searchcounter} steps to complete");

                            for (int i = 0; i < DoubleHigh_Low_Array.Length;)
                            {
                                while (key != DoubleHigh_Low_Array[i])
                                {
                                    i++;
                                }
                                foreach (int instance in DoubleHigh_Low_Array)
                                {
                                    if (key == instance)
                                    {
                                        mentions++;
                                    }
                                }
                                if (key == DoubleHigh_Low_Array[i])
                                {
                                    Console.WriteLine($"{key} is the {i}th value in your array");
                                    break;
                                }
                                if (mentions > 1)
                                {
                                    Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleHigh_Low_Array[i]} and {DoubleHigh_Low_Array[i + 1]}");
                                    break;
                                }
                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                            string answer = Console.ReadLine();

                            if (answer.ToUpper() == "Y")
                            {
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleHigh_Low_Array.Length - 1;
                                int counter = 0;
                                BinarySearch_R(key, DoubleHigh_Low_Array, low, high, ref counter);

                                for (int i = 0; i < DoubleHigh_Low_Array.Length;)
                                {
                                    while (key > DoubleHigh_Low_Array[i])
                                    {
                                        i++;
                                    }
                                    /*  if (key < DoubleHighWeatherArray[i])
                                      {
                                          Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                          break;
                                      }*/
                                    if (key < DoubleHigh_Low_Array[i])
                                    {
                                        double left_side = key - DoubleHigh_Low_Array[i - 1];
                                        double right_side = DoubleHigh_Low_Array[i] - key;
                                        //double closestvalue = right_side > left_side ? left_side : right_side;
                                        if (right_side > left_side)
                                            Console.WriteLine($"{DoubleHigh_Low_Array[i - 1]} would be the closest value");
                                        else
                                        {
                                            Console.WriteLine($"{DoubleHigh_Low_Array[i]} would be the closest value");
                                        }
                                        break;
                                    }
                                }
                            }
                            else if (answer.ToUpper() == "N")
                            {
                            }
                        }
                        catch (Exception e) { Console.WriteLine(e.Message); }
                    }
                }
                else if (option == 2)
                {

                    Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                    int order = Convert.ToInt32(Console.ReadLine());

                    if (order == 1)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_2048.txt");
                        string High = File.ReadAllText("High_2048.txt");
                        int N_O_Elements = 4096;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_2048.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        BinarySearchTreeSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 2)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_2048.txt");
                        string High = File.ReadAllText("High_2048.txt");
                        int N_O_Elements = 4096;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_2048.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        DescendingOrderQuickSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 3)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_2048.txt");
                        string High = File.ReadAllText("High_2048.txt");
                        int N_O_Elements = 4096;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_2048.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        Displacement_ValueQuickSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 4)
                    {
                        int Sortcounter = 0;
                        string Low = File.ReadAllText("Low_2048.txt");
                        string High = File.ReadAllText("High_2048.txt");
                        int N_O_Elements = 4096;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_2048.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        BinarySearchTreeSort(DoubleHigh_Low_Array, Sortcounter);
                        try
                        {
                            int Searchcounter = 0;
                            int mentions = 0;
                            Console.WriteLine("What Value are you looking for?");
                            double key = double.Parse(Console.ReadLine());
                            Node r = new Node();// create an instance of node so i can call it
                            BinarySearchTreeSearch(r, key, ref Searchcounter);
                            Console.WriteLine($"This search took {Searchcounter} steps to complete");

                            for (int i = 0; i < DoubleHigh_Low_Array.Length;)
                            {
                                while (key != DoubleHigh_Low_Array[i])
                                {
                                    i++;
                                }
                                foreach (int instance in DoubleHigh_Low_Array)
                                {
                                    if (key == instance)
                                    {
                                        mentions++;
                                    }
                                }
                                if (key == DoubleHigh_Low_Array[i])
                                {
                                    Console.WriteLine($"{key} is the {i}th value from your node");
                                    break;
                                }
                                if (mentions > 1)
                                {
                                    Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleHigh_Low_Array[i]} and {DoubleHigh_Low_Array[i + 1]}");
                                    break;
                                }
                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                            string answer = Console.ReadLine();

                            if (answer.ToUpper() == "Y")
                            {
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleHigh_Low_Array.Length - 1;
                                int counter = 0;
                                BinarySearch_R(key, DoubleHigh_Low_Array, low, high, ref counter);

                                for (int i = 0; i < DoubleHigh_Low_Array.Length;)
                                {
                                    while (key > DoubleHigh_Low_Array[i])
                                    {
                                        i++;
                                    }
                                    /*  if (key < DoubleHighWeatherArray[i])
                                      {
                                          Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                          break;
                                      }*/
                                    if (key < DoubleHigh_Low_Array[i])
                                    {
                                        double left_side = key - DoubleHigh_Low_Array[i - 1];
                                        double right_side = DoubleHigh_Low_Array[i] - key;
                                        //double closestvalue = right_side > left_side ? left_side : right_side;
                                        if (right_side > left_side)
                                            Console.WriteLine($"{DoubleHigh_Low_Array[i - 1]} would be the closest value");
                                        else
                                        {
                                            Console.WriteLine($"{DoubleHigh_Low_Array[i]} would be the closest value");
                                        }
                                        break;
                                    }
                                }
                            }
                            else if (answer.ToUpper() == "N")
                            {
                            }
                        }
                        catch (Exception e) { Console.WriteLine(e.Message); }
                    }
                }

                else if (option == 3)
                {

                    Console.WriteLine("1.Sort in Ascending order\n2.Sort in Descending order\n3.Display values in a chosen increment i.e every 10th value\n4.Search for a specific value");
                    int order = Convert.ToInt32(Console.ReadLine());

                    if (order == 1)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_4096.txt");
                        string High = File.ReadAllText("High_4096.txt");
                        int N_O_Elements = 8192;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_4096.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        BinarySearchTreeSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 2)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_4096.txt");
                        string High = File.ReadAllText("High_4096.txt");
                        int N_O_Elements = 8192;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_4096.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        DescendingOrderQuickSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 3)
                    {
                        int counter = 0;
                        string Low = File.ReadAllText("Low_4096.txt");
                        string High = File.ReadAllText("High_4096.txt");
                        int N_O_Elements = 8192;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_4096.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        Displacement_ValueQuickSort(DoubleHigh_Low_Array, counter);
                    }
                    else if (order == 4)
                    {
                        int Sortcounter = 0;
                        string Low = File.ReadAllText("Low_4096.txt");
                        string High = File.ReadAllText("High_4096.txt");
                        int N_O_Elements = 8192;
                        double[] DoubleHigh_Low_Array = new double[N_O_Elements];
                        string filename = "High_Low_4096.txt";
                        FileMerger.FilesToMerge(High, Low, filename);
                        string High_Low = File.ReadAllText(filename);

                        PrintData(High_Low, DoubleHigh_Low_Array, N_O_Elements);
                        BinarySearchTreeSort(DoubleHigh_Low_Array, Sortcounter);
                        try
                        {
                            int Searchcounter = 0;
                            int mentions = 0;
                            Console.WriteLine("What Value are you looking for?");
                            double key = double.Parse(Console.ReadLine());                       
                            Node r = new Node();
                            BinarySearchTreeSearch(r, key, ref Searchcounter);
                            Console.WriteLine($"This search took {Searchcounter} steps to complete");

                            for (int i = 0; i < DoubleHigh_Low_Array.Length;)
                            {
                                while (key != DoubleHigh_Low_Array[i])
                                {
                                    i++;
                                }
                                foreach (int instance in DoubleHigh_Low_Array)
                                {
                                    if (key == instance)
                                    {
                                        mentions++;
                                    }
                                }
                                if (key == DoubleHigh_Low_Array[i])
                                {
                                    Console.WriteLine($"{key} is the {i}th value from your node");
                                    break;
                                }
                                if (mentions > 1)
                                {
                                    Console.WriteLine($"There are {mentions} mentions of this temperature at {DoubleHigh_Low_Array[i]} and {DoubleHigh_Low_Array[i + 1]}");
                                    break;
                                }
                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            Console.WriteLine("This value does not exist in you array...\nWould you like to find the closest value to it? Y OR N");
                            string answer = Console.ReadLine();

                            if (answer.ToUpper() == "Y")
                            {
                                Console.WriteLine("What Value are you looking for?");
                                double key = double.Parse(Console.ReadLine());
                                int low = 0;
                                int high = DoubleHigh_Low_Array.Length - 1;
                                int counter = 0;
                                BinarySearch_R(key, DoubleHigh_Low_Array, low, high, ref counter);

                                for (int i = 0; i < DoubleHigh_Low_Array.Length;)
                                {
                                    while (key > DoubleHigh_Low_Array[i])
                                    {
                                        i++;
                                    }
                                    /*  if (key < DoubleHighWeatherArray[i])
                                      {
                                          Console.WriteLine($"{DoubleHighWeatherArray[i]} would be the closest value with a difference of {DoubleHighWeatherArray[i] - key}");
                                          break;
                                      }*/
                                    if (key < DoubleHigh_Low_Array[i])
                                    {
                                        double left_side = key - DoubleHigh_Low_Array[i - 1];
                                        double right_side = DoubleHigh_Low_Array[i] - key;
                                        //double closestvalue = right_side > left_side ? left_side : right_side;
                                        if (right_side > left_side)
                                            Console.WriteLine($"{DoubleHigh_Low_Array[i - 1]} would be the closest value");
                                        else
                                        {
                                            Console.WriteLine($"{DoubleHigh_Low_Array[i]} would be the closest value");
                                        }
                                        break;
                                    }
                                }
                            }
                            else if (answer.ToUpper() == "N")
                            {
                            }
                        }
                        catch (Exception e) { Console.WriteLine(e.Message); }
                    }
                }
                
            }
            Console.ReadKey();
        }

        public static void PrintData(string WeatherData, double[] DataArray, int FileSize) {
            for (int i = 0; i < FileSize; i++)
            {
                string[] Data = WeatherData.Split(' ');
                string x = Data[i].Trim();
                if (x == " ")
                {
                    x = Regex.Replace(x, @"\s+", " ");
                    continue;
                }
                else
                {
                    Double.TryParse(x, out DataArray[i]);
                    // Console.WriteLine(DataArray[i]); //commented out unless needed for testing
                }
            }
        }
        //}
        //Ascending order Quicksort
        public static void AscendingOrderQuickSort(double[] data, int counter)// to make the code able to sort 3 and 4 just change data types
        {
            // pre: 0 <= n <= data.length
            // post: values in data[0 … n-1] are in ascending order
            AscendingOrderQuick_Sort(data, 0, data.Length - 1, ref counter);
            foreach (var num in data)
            {
                Console.WriteLine(num);
            }
            Console.WriteLine($"The sort took {counter} steps to complete");           
        }

        public static void AscendingOrderQuick_Sort(double[] data, int left, int right, ref int counter)// to make the code able to sort 3 and 4 just change the array data types
        {
            int i, j;// 0 is not a double data type and these arrays have to start on zero defore you cannot declare i and j as doubles, they have to be INTs
            double pivot, temp;// to make the code able to sort 3 and 4 just change data types
            i = left;
            j = right;
            pivot = data[(left + right) / 2];
            do
            {
                counter++;
                while ((data[i] < pivot) && (i < right)) i++;//while data is greater than pivot point keep going on to the next value
                while ((pivot < data[j]) && (j > left)) j--;//while pivot is greater than value you are on and your value is greater than the value to the left of it, then go left. goes from positive to negative or big to small
                if (i <= j)
                {
                    temp = data[i];
                    data[i] = data[j];
                    data[j] = temp;
                    i++;
                    j--;
                }
            } while (i <= j);
            if (left < j) AscendingOrderQuick_Sort(data, left, j, ref counter);
            if (i < right) AscendingOrderQuick_Sort(data, i, right, ref counter);
        }
        //Descending order Quicksort
        public static void DescendingOrderQuickSort(double[] data, int counter)// to make the code able to sort 3 and 4 just change data types
        {
            // pre: 0 <= n <= data.length
            // post: values in data[0 … n-1] are in ascending order
            DescendingOrderQuick_Sort(data, 0, data.Length - 1, ref counter);
            foreach (var num in data)
            {
                Console.WriteLine(num);
            }
            Console.WriteLine($"The sort took {counter} steps to complete");
        }

        public static void DescendingOrderQuick_Sort(double[] data, int left, int right, ref int counter)// to make the code able to sort 3 and 4 just change the array data types
        {
            int i, j;// 0 is not a double data type and these arrays have to start on zero defore you cannot declare i and j as doubles, they have to be INTs
            double pivot, temp;// to make the code able to sort 3 and 4 just change data types
            i = left;
            j = right;
            pivot = data[(left + right) / 2];
            do
            {
                counter++;
                while ((data[i] > pivot) && (i < right)) i++;//while data is greater than pivot point keep going on to the next value
                while ((pivot > data[j]) && (j > left)) j--;//while pivot is greater than value you are on and your value is greater than the value to the left of it, then go left. goes from positive to negative or big to small
                if (i <= j)
                {
                    temp = data[i];
                    data[i] = data[j];
                    data[j] = temp;
                    i++;
                    j--;
                }
            } while (i <= j);
            if (left < j) DescendingOrderQuick_Sort(data, left, j, ref counter);
            if (i < right) DescendingOrderQuick_Sort(data, i, right, ref counter);
        }
        //Displaying the 10th value in ascending order
        public static void Displacement_ValueQuickSort(double[] data, int counter)// to make the code able to sort 3 and 4 just change data types
        {
            Console.WriteLine("Enter your displacement");
            int displacement = Convert.ToInt32(Console.ReadLine());
            // pre: 0 <= n <= data.length
            // post: values in data[0 … n-1] are in ascending order
            Displacement_ValueQuick_Sort(data, 0, data.Length - 1, displacement, ref counter);
            for (int i = 0; i + displacement < data.Length;) {
                Console.WriteLine(data[i = i + displacement]);
            }
            Console.WriteLine($"The sort took {counter} steps to complete");
        }

        public static void Displacement_ValueQuick_Sort(double[] data, int left, int right, int displacement, ref int counter)// to make the code able to sort 3 and 4 just change the array data types
        {
            int i, j;// 0 is not a double data type and these arrays have to start on zero defore you cannot declare i and j as doubles, they have to be INTs
            double pivot, temp;// to make the code able to sort 3 and 4 just change data types
            i = left;
            j = right;
            pivot = data[(left + right) / 2];
            do
            {
                counter++;
                while ((data[i] < pivot) && (i < right)) i++;//while data is greater than pivot point keep going on to the next value
                while ((pivot < data[j]) && (j > left)) j--;//while pivot is greater than value you are on and your value is greater than the value to the left of it, then go left. goes from positive to negative or big to small
                if (i <= j)
                {
                    temp = data[i];
                    data[i] = data[j];
                    data[j] = temp;
                    i++;
                    j--;
                }
            } while (i <= j);
            if (left < j) Displacement_ValueQuick_Sort(data, left, j, displacement, ref counter);
            if (i < right) Displacement_ValueQuick_Sort(data, i, right, displacement, ref counter);
        }
        // Quicksort
        public static void QuickSort(double[] data, int counter)// to make the code able to sort 3 and 4 just change data types
        {
            // pre: 0 <= n <= data.length
            // post: values in data[0 … n-1] are in ascending order
            Quick_Sort(data, 0, data.Length - 1, ref counter);
            Console.WriteLine($"The sort took {counter} steps to complete");
        }

        public static void Quick_Sort(double[] data, int left, int right, ref int counter)// to make the code able to sort 3 and 4 just change the array data types
        {
            int i, j;// 0 is not a double data type and these arrays have to start on zero defore you cannot declare i and j as doubles, they have to be INTs
            double pivot, temp;// to make the code able to sort 3 and 4 just change data types
            i = left;
            j = right;
            pivot = data[(left + right) / 2];
            do
            {
                counter++;
                while ((data[i] < pivot) && (i < right)) i++;//while data is greater than pivot point keep going on to the next value
                while ((pivot < data[j]) && (j > left)) j--;//while pivot is greater than value you are on and your value is greater than the value to the left of it, then go left. goes from positive to negative or big to small
                if (i <= j)
                {
                    temp = data[i];
                    data[i] = data[j];
                    data[j] = temp;
                    i++;
                    j--;
                }
            } while (i <= j);
            if (left < j) Quick_Sort(data, left, j, ref counter);
            if (i < right) Quick_Sort(data, i, right, ref counter);
        }
        //BinarySearch
        static double BinarySearch_R(double key, double[] array, int low, int high, ref int counter)
        {
            counter++;
            if (low > high) return -1;
            int mid = (low + high) / 2;
            if (key == array[mid])
            {
                return mid;
            }
            if (key < array[mid])
            {
                return BinarySearch_R(key, array, low, mid - 1, ref counter);
            }
            else
            {
                return BinarySearch_R(key, array, mid + 1, high, ref counter);
            }
        }
        //Bubble Sort
        static int DescendingOrder_BubbleSort(double[] array, int n)
        {
            int counter = 0;
            double temp = 0;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - 1 - i; j++)
                {// tells you the number of steps left to be taken by using the total value -1 s0 31 subtract the steps already taken, leaving us with how many steps are left
                    if (array[j + 1] < array[j])
                    {
                        temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                        counter++;
                    }
                }
                Console.WriteLine(temp);
            }
            Console.WriteLine($"The sort took {counter} steps to complete");
            return 1;
        }
        // Insertion Sort
        static void DescendingOrder_InsertionSort(double[] data)
        {
            //pre: 0 <= x<= data.Length
            //post: values in data[0...n-1] are in ascending order
            int numberSorted = 1; // number of values in place
            int index; // general index;
            int x = data.Length;
            int counter = 0;
            while (numberSorted < x)
            {
                //take the first unsorted value
                double temp = data[numberSorted];// is s place holder for data about to be sorted
                // ... and insert it among the sorted
                for (index = numberSorted; index > 0; index--)
                {
                    if (temp > data[index - 1])// change my symbol to print in ascending order
                    {
                        // prints values not fully sorted
                        data[index] = data[index - 1];
                        counter++;
                        // prints some in order and some not
                    }
                    else
                    {
                        // prints if no sorting has taken place
                        break;
                    }
                    // prints not fuly sorted at this point temp is only holding one value
                }
                //reinsert value unsorted
                data[index] = temp;
                numberSorted++;
            }
            for (int i = 0; i < data.Length; i++)
            {
                Console.WriteLine(data[i]);
            }
            Console.WriteLine($"The sort took {counter} steps to complete");
        }
        //Linear Search algorithm
        public static double LinearSearch(double[] data, double key)
        {
            for (int i = 0; i < data.Length; i++)
                if (data[i] == key)
                    return i;          
            return -1;
        }
        //Binary Tree Sort for Sorting
        public static void BinarySearchTreeSort(double[] WeatherArray, int counter)
        {
            Node root = null;
            Tree BinarySearchTree = new Tree();

            for (int i = 0; i < WeatherArray.Length; i++)
            {
                root = BinarySearchTree.Insert(root, WeatherArray[i], ref counter);// this puts the values of the array into the binary search tree.
            }
            BinarySearchTree.Traverse(root);// this allows the tree to seach through itself.
            Console.WriteLine($"The sort took {counter} steps to complete");
        }

        //Binary Tree for Searching
        public static double BinarySearchTreeSearch(Node branch, double key, ref int counter)
        {
            counter++;
            if (branch == null)
            {
                return 0;
            }
            if (branch.value == key)
            {
                return key;
            }
            else if (key < branch.value)
            {
                return BinarySearchTreeSearch(branch.left, key, ref counter);
            }
            else
            {
                return BinarySearchTreeSearch(branch.right, key, ref counter);
            }
        }
    }
}

