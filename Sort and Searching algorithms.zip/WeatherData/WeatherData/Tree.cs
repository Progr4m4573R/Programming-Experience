﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherData
{
    class Tree
    {
        public Node Insert(Node root, double New_value, ref int counter)
        {// inserts a new value into the tree
            counter++;
            if (root == null)
            {// if the current value in the tree is the last value...
                root = new Node
                {
                    value = New_value// putting that new double value into the new node we just created if the node was empty
                }; //the root becauses a new node, a new starting pooint to add values onto. the new node acts like a class so you call a data member from it.
                   //  Console.WriteLine(root.value);// before sorting
            }
            else if (New_value < root.value)
            {// if the new value we are adding is less than the last value in the node then we add it to the left of the root
                root.left = Insert(root.left, New_value, ref counter); // we insert the new value into the tree by calling the insert function which takes a node or location to insert into and the value
            }
            else
            {// if the value is greater than the last value in the node then we put it to the right of that value
                root.right = Insert(root.right, New_value, ref counter);
            }           
            return root;// then we return the root or value we are at
        }

        public void Traverse(Node root)
        {// to move around a tree we take in the top value and if it is not an empty tree then we go left before right this is an inorder traversal
            if (root == null)
            {// if it is empty then do nothing
                return;
            }
            Traverse(root.left);// if it is not empty then call the traverse function and keep going right until you have gone through all the values on the right side
            Console.WriteLine(root.value);// this is an in order traversal because it traverses the tree in the following order, left sub-tree, node, right sub-tree
            Traverse(root.right);// Then call the traverse function for the left side until you have gone through all the values
            //Console.WriteLine(root.value);
        }
    }
}
